# Testing Functions
usethis::use_testthat()

### LOOK AT TESTTHIS FOR LOGISTIC REGRESSION OUTPUT
usethis::use_test("test_functions.R")
