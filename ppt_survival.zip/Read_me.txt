The ppt program contains the main and child R files.
The main R file sets up the dataset and also includes the key portion
of providing a template ppt style to use in the YAML/header. 
The main file is where we bring in the appropriate data and provide 
the different variables that you want to loop through in the child file. 
This is the file you use "Knit to Powerpoint"

The child R file is where you create whatever viz you want. In this case
we are creating a survival plot and another graph after that. This is highly
flexible and could add in any sort of graphs/tables/prose you might want. 

