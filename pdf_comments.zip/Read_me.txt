To get comments into a pdf file and then retrieve those comments you:
1: Run the multiplot_clinUtilData program to create a pdf file that contains comment boxes and graphs. 
(Still needs to be tested with realistic data outside of the clinUtils package)
2: Make comments on the newly created pdf document. 
3: Save pdf file
4: Open the extractor.RMD file and using the pdf_text function, change the file name to your saved pdf file
5: Knit using the extractor.RMD file and you will have a table with comments.