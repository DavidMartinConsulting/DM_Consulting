library(pdftools)
library(tidyverse)
full_pdf <- pdf_text(pdf = "mp_test.pdf")[-1]
full_pdf
full_pdf_split <- str_split(full_pdf, "Comments about Subject")

saved <- unlist(full_pdf_split)[seq(2,length(unlist(full_pdf_split)),2)]
subjid <- trimws(str_extract(saved, "[0-9]{2}[-][0-9]{3}[-][0-9]{4}"))
measure_type <- trimws(str_extract(saved, "(?<=,).*(?=::)"))

s2 <- str_replace(saved, subjid, "")
s3 <- str_replace(s2, paste0("Subject ", subjid, ", ", measure_type), "")
s4 <- str_replace_all(s3, ":", "")
s5 <- trimws(str_replace(s4, "[0-9]+[\n]$", ""))

comments <- bind_cols(subjid, measure_type, s5)
names(comments) <- c("Subject_ID", "Measure_Type", "Comments")
comments %>% filter(Comments != "")

